Static web shopping form order whatsapp with google authentication,

base on jekyllv.4.2 and ionic framework v.6

site : [https://plus62store.my.id](https://plus62store.my.id)