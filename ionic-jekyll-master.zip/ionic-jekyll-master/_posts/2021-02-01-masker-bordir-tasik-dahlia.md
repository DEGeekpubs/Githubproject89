---
title: Masker Bordir Dahlia
description: Masker kain bordir manual tasikmalaya murah meriah,
categories: masker-bordir
price: '20.000'
diskon: 22%
discount: '15.600'
stok: Stok Habis
rating: 5.0
rC: 3201
riv: 3500
sku: dahlia
mpn: p62s-2134
noID: i.226754372.7253556909
stars: star
tali:
  - HeadLoop
  - EarLoop
  - Tali Ikat
styles:
  - name: Navi
    color: '#4a5265'
    image_path: https://cf.shopee.co.id/file/706de3404cf14e97c9e321ee4011ef48
  - name: Mustard
    color: '#efa22c'
    image_path: https://cf.shopee.co.id/file/7b97bd021da31ba26e893e411ffd1c37
  - name: Krem
    color: '#d5c4b0'
    image_path: https://cf.shopee.co.id/file/2c2d63fdab9064c091de7353ed387d36
  - name: Coksu
    color: '#b48c69'
    image_path: https://cf.shopee.co.id/file/1765056e8a8cec8219a446bc000f6ec2
  - name: Abu
    color: '#a1a2a7'
    image_path: https://cf.shopee.co.id/file/8871c8e8e4faff80da54f291ae8ff924
  - name: Pink
    color: '#d07897'
    image_path: https://cf.shopee.co.id/file/d59989ac225832a3791e88e9388d4666
  - name: Toska
    color: '#298f83'
    image_path: https://cf.shopee.co.id/file/df0a91841d6b71c9f4b96066ccc853f3
image: 'https://cf.shopee.co.id/file/6549ebebfdff7f4355dc0398f5f5b9e2'
facebook_image_path:
- https://cf.shopee.co.id/file/706de3404cf14e97c9e321ee4011ef48
- https://cf.shopee.co.id/file/7b97bd021da31ba26e893e411ffd1c37
- https://cf.shopee.co.id/file/2c2d63fdab9064c091de7353ed387d36
- https://cf.shopee.co.id/file/1765056e8a8cec8219a446bc000f6ec2
- https://cf.shopee.co.id/file/8871c8e8e4faff80da54f291ae8ff924
- https://cf.shopee.co.id/file/d59989ac225832a3791e88e9388d4666
- https://cf.shopee.co.id/file/df0a91841d6b71c9f4b96066ccc853f3
display: block
---

- Jenis Kain : Katun, 3 ply/lapis,
- Lapisan Tengah : Interlining,
- Model : HeadLoop dan EarLoop,
- Tinggi Masker 14cm,
- Lebar Masker 13cm ( satu sisi )
