---
title: Masker Bordir sMaya
description: Bahan Kain Katun, 3 lapis,
categories: masker-bordir
price: '20.000'
diskon: 22%
discount: '15.600'
stok: Stok Habis
rating: 5.0
rC: 2265
riv: 3550
sku: smaya
mpn: p62s-2200
noID: i.226754372.3554451614
stars: star
tali:
  - HeadLoop
  - EarLoop
  - Tali Ikat
styles:
  - name: Navi
    color: '#4a5265'
    image_path: https://cf.shopee.co.id/file/deb4a4112bd9251a9a8798950a3b14af
  - name: Mustard
    color: '#efa22c'
    image_path: https://cf.shopee.co.id/file/82a451d72f07d02d0665b2afe748885e
  - name: Krem
    color: '#d5c4b0'
    image_path: https://cf.shopee.co.id/file/203315c03f6311a8761ac045e57480d3
  - name: Coksu
    color: '#b48c69'
    image_path: https://cf.shopee.co.id/file/ceb2192e68b80af6eba4b9df1826c89f
  - name: Abu
    color: '#a1a2a7'
    image_path: https://cf.shopee.co.id/file/f44712fe6dd203482190125d0fdc08af
  - name: BirMud
    color: '#b8c5d6'
    image_path: https://cf.shopee.co.id/file/d48282c333191ff45effa94ed15b2993
  - name: Hitam
    color: '#000'
    image_path: https://cf.shopee.co.id/file/19cc7a4f1ba1a82f2596323730ca093b
  - name: Ungu
    color: '#8464a5'
    image_path: https://cf.shopee.co.id/file/ab2777be709bc6aa0c31093c23b1b566
image: 'https://cf.shopee.co.id/file/0f895509b187d2da6ae3e06a460841c0'
facebook_image_path:
- https://cf.shopee.co.id/file/0f895509b187d2da6ae3e06a460841c0
- https://cf.shopee.co.id/file/deb4a4112bd9251a9a8798950a3b14af
- https://cf.shopee.co.id/file/82a451d72f07d02d0665b2afe748885e
- https://cf.shopee.co.id/file/203315c03f6311a8761ac045e57480d3
- https://cf.shopee.co.id/file/ceb2192e68b80af6eba4b9df1826c89f
- https://cf.shopee.co.id/file/f44712fe6dd203482190125d0fdc08af
- https://cf.shopee.co.id/file/d48282c333191ff45effa94ed15b2993
- https://cf.shopee.co.id/file/19cc7a4f1ba1a82f2596323730ca093b
- https://cf.shopee.co.id/file/ab2777be709bc6aa0c31093c23b1b566
display: block
---

- Lapisan Tengah : Interlining,
- Bordir : Manual ( JUKI ),
- Model : HeadLoop dan EarLoop,
- Tinggi 14cm, Lebar 13cm (satu sisi).
