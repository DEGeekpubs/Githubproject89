---
title: Masker Bordir Ilalang
description: Masker Kain Bordir Bunga. -Bahan kain 100% Katun dengan 3 lapisan.
categories: masker-bordir
price: '20.000'
diskon: 22%
discount: '15.600'
stok: Tersedia
rating: 5.0
rC: 3604
riv: 3853
sku: ilalang
mpn: p62s-2219
noID: i.226754372.6457391578
stars: star
tali:
  - HeadLoop
  - EarLoop
  - Tali Ikat
styles:
  - name: Hitam
    color: '#000'
    image_path: https://cf.shopee.co.id/file/b03ca4dd60056b6a17fb142751a84cd3
  - name: Navi
    color: '#4a5265'
    image_path: https://cf.shopee.co.id/file/10fd8e4c6858dc6ec1e8a530a5fb6621
  - name: Marun
    color: '#ba2342'
    image_path: https://cf.shopee.co.id/file/1c2bd68efc8e5856c35f516831b0018d
  - name: Mustard
    color: '#efa22c'
    image_path: https://cf.shopee.co.id/file/114e691553bdeb88648c8e5339f7196a
  - name: Ungu
    color: '#8464a5'
    image_path: https://cf.shopee.co.id/file/25ff5e0bc98b7f5fa813e0c49da3f62c
  - name: Abu
    color: '#a1a2a7'
    image_path: https://cf.shopee.co.id/file/f1ff7e7d7dcd04231bbe267c9bca4b07
  - name: Pink
    color: '#d07897'
    image_path: https://cf.shopee.co.id/file/1ada2636aaa18cc18fcfc6415526f48a
image: 'https://cf.shopee.co.id/file/0031e5ba7ee62316a17ecbd36ec7bff6'
facebook_image_path:
- https://cf.shopee.co.id/file/b03ca4dd60056b6a17fb142751a84cd3
- https://cf.shopee.co.id/file/10fd8e4c6858dc6ec1e8a530a5fb6621
- https://cf.shopee.co.id/file/1c2bd68efc8e5856c35f516831b0018d
- https://cf.shopee.co.id/file/114e691553bdeb88648c8e5339f7196a
- https://cf.shopee.co.id/file/25ff5e0bc98b7f5fa813e0c49da3f62c
- https://cf.shopee.co.id/file/f1ff7e7d7dcd04231bbe267c9bca4b07
- https://cf.shopee.co.id/file/1ada2636aaa18cc18fcfc6415526f48a
display: block
---

- Lapisan Katun + Vislin,
- Bordir Manual ( JUKI ),
- Tali Karet Earloop & Headloop.
- Tali Kain Ikat
