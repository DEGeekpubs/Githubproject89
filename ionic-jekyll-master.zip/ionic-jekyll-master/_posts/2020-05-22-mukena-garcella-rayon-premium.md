---
title: Mukena Garcella
description: Material -Rayon Premium, -Renda Giffer Premium. -1Set Mukena, Rok & Tas
categories: mukena-garcella
tags: Terbaru
price: '185.000'
diskon: 12%
discount: '162.600'
stok: Tersedia
rating: 5.0
rC: 1205
riv: 1355
sku: garcella
mpn: p62s-0205
noID: i.226754372.9136934817
stars: star
tali:
  - Tali Ikat
styles:
  - name: Marun
    color: '#ba2342'
    image_path: https://cf.shopee.co.id/file/09a49f974223ab7ee852275e9c0193e0
  - name: Navi
    color: '#4a5265'
    image_path: https://cf.shopee.co.id/file/6c3c76cf17cb55a7a4e6a1a3f138e2e8
  - name: Hitam
    color: '#000'
    image_path: https://cf.shopee.co.id/file/af3f66497bb1559c73619bdaaf38e539
  - name: Coksu
    color: '#b48c69'
    image_path: https://cf.shopee.co.id/file/f3e89f094e8c67e67f953680d14817d6
  - name: Hijau
    color: '#023439'
    image_path: https://cf.shopee.co.id/file/0e200dc5e3d7509e77a839e5f8e98717
image: 'https://cf.shopee.co.id/file/09a49f974223ab7ee852275e9c0193e0'
facebook_image_path:
- https://cf.shopee.co.id/file/09a49f974223ab7ee852275e9c0193e0
- https://cf.shopee.co.id/file/6c3c76cf17cb55a7a4e6a1a3f138e2e8
- https://cf.shopee.co.id/file/af3f66497bb1559c73619bdaaf38e539
- https://cf.shopee.co.id/file/f3e89f094e8c67e67f953680d14817d6
- https://cf.shopee.co.id/file/0e200dc5e3d7509e77a839e5f8e98717
display: none
---

### Material : 

- Rayon Premium,
- Renda Giffer Premium.

### Kriteria satu pack nya : 

- Bahan Adem & Halus, Tidak Menerawang Sehingga Nyaman di Pakai Untuk Beribadah, 
- Jahitan Kuat, Awet Tidak Mudah Robek, 
- Ujung Rok/bawahan Pakai Renda, 
- Ikat Kepala Pakai tali Ikat. 

### Ukuran

(menurut cm Depan & Belakang)
- Atasan, 
- Panjang depan+Renda :125 cm, 
- Panjang belakang+ Renda : 135 cm, 
- Tinggi 123cm, 
- Lingkarang full 150cm, 
- Panjang Rok 119cm, 
- Lingkaran Rok 154cm, 
- BERAT 1PCS : 780gr.

